package mx.tecnm.tepic.ladm_u1_p2_archivos_memoria_interna_y_externa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnmas.setOnClickListener {
            ventanaNuevaNota()
        }

        btnabrir.setOnClickListener {
            eliminar()
        }


        btnborrar.setOnClickListener {
            //abrir()
        }
    }


    /*fun abrir(){}
    fun guardar(){}*/

    fun ventanaNuevaNota(){
        val nota = EditText(this)
        //val titulo = EditText(this)
        nota.inputType = InputType.TYPE_CLASS_TEXT
        //titulo.inputType = InputType.TYPE_CLASS_TEXT

        AlertDialog.Builder(this)
            .setTitle("NUEVA NOTA")
            .setMessage("CAPTURE SU NOTA")
            .setView(nota)
            .setPositiveButton("CANCELAR"){d,i->
                d.cancel()
            }
            .setNegativeButton("CREAR"){d,i->
                //crearCamposTexto(nota.text.toString().toInt())
                insertar(nota.text.toString())
                d.dismiss()
            }
            .show()
    }


    fun insertar(valor:String){
        val vector = ArrayList<TextView>()
        var nombre = valor
        val campoN = TextView(this)
        vector.add(campoN)
        campoN.setText(nombre)
        linear.addView(campoN)
    }

    /*fun crearCamposTexto(valor:Int) {
        val etiqueta = TextView(this)
        etiqueta.setText("CAPTURE LOS VALORES")

        linear.addView(etiqueta)

        val vectorCamposTexto = ArrayList<EditText>()
        var cantidadTotal = (valor - 1).toInt()
        (0..cantidadTotal).forEach() {
            val campoTexto = EditText(this)
            vectorCamposTexto.add(campoTexto)
            campoTexto.setHint("Valor ${it + 1}")
            linear.addView(campoTexto)
        }
    }*/

    fun eliminar(){
        val cantidad = EditText(this)
        cantidad.inputType = InputType.TYPE_CLASS_NUMBER

        AlertDialog.Builder(this)
            .setTitle("ATENCION")
            .setMessage("ID A ELIMINAR")
            .setView(cantidad)
            .setPositiveButton("CANCELAR"){d,i->
                d.cancel()
            }
            .setNegativeButton("BORRAR"){d,i->
                //d.dismiss()
            }
            .show()
    }
}